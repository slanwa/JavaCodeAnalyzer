/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package codeanalyser;

/**
 *
 * @author moise
 */
import javax.tools.*;
import java.io.*;
import java.util.*;

public class CodeAnalyzer {
    public static void main(String[] args) {
        String fileToAnalyze = "C:/Users/moise/OneDrive/Documents/NetBeansProjects/test1/src/test1/Test1.java"; // file to analyze
        File file = new File(fileToAnalyze);

        // Set up the JavaCompiler
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, null, null);

        Iterable<? extends JavaFileObject> compilationUnits = fileManager.getJavaFileObjectsFromFiles(Arrays.asList(file));
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();

        // Compile the code and capture diagnostics (errors/warnings)
        JavaCompiler.CompilationTask task = compiler.getTask(null, fileManager, diagnostics, null, null, compilationUnits);
        boolean success = task.call();

        if (success) {
            System.out.println("No syntax errors found.");
        } else {
            for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
                System.out.println("Error on line " + diagnostic.getLineNumber() + ": " + diagnostic.getMessage(null));
            }
        }
    }
}

